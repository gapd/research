ディレクトリーに適当なファイル名でプロパティー・ファイル (.properties) を
作成することで、オリジナルの訳を追加することができます。
readme/readme_pleiades.txt の
Pleiades 起動オプションの enabled.not.found.log を参照してください。
